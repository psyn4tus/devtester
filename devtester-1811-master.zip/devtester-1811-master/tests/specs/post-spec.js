const LoginPage = require('../pages/login-page.js');

describe('Compartilhar foto', () => {

    const loginPage = new LoginPage();

    describe('quando eu compartilho uma nova foto', () => {

        let imageName = 'passeio-dunas.jpg';

        beforeAll(() => {

            loginPage.go();
            loginPage.with('eu@papito.io', '123456');

            let remote = require('selenium-webdriver/remote');
            browser.setFileDetector(new remote.FileDetector());

            let path = require('path');
            let imageShare = './../fixtures/' + imageName;
            let absolutPath = path.resolve(__dirname, imageShare);

            element(by.id('photoId')).sendKeys(absolutPath);
        })


        it('então esta foto deve ser exibida na timeline', async () => {
            browser.sleep(3000)
            let photos = await element.all(by.css('.imageShare'))

            photos[0].getAttribute('src').then(value => {
                expect(value).toContain(imageName)
            });
        })

    });



})