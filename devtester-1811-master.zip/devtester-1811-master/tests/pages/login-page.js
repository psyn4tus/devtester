class LoginPage {
    constructor() {
        this.inputEmail = element(by.css('input[name=email]'))
        this.inputPassword = element(by.css('input[name=password]'))
        this.submit = element(by.id('signin'))
    }

    go() {
        browser.get('/login')
    }

    with(email, pass) {
        this.inputEmail.sendKeys(email)
        this.inputPassword.sendKeys(pass)
        this.submit.click()
    }
}

module.exports = LoginPage;