import { Mongo } from 'meteor/mongo';

export const Posts = new Mongo.Collection('posts');