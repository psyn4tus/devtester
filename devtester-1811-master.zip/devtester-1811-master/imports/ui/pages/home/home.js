import './home.html';

import '../../components/menu/menu.js'
import '../../components/footer/footer.js'
import '../../components/posts/posts.js'

