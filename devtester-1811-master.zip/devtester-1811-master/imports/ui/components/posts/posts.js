import { Posts } from '/imports/api/posts/posts.js';
import { Meteor } from 'meteor/meteor';
import './posts.html'

Template.posts.onCreated(function () {
    Meteor.subscribe('posts.all');
});

Template.posts.helpers({
    posts() {
        return Posts.find({}, { sort: { 'createdAt': -1 } });
    },
    totalLikes(likes) {
        return likes.length;
    },
    myPost(userId) {
        if (userId == Meteor.userId()) {
            return true;
        } else {
            return false;
        }
    }
});

Template.posts.events({
    'click .heart': function (event) {
        event.preventDefault();

        Meteor.call('posts.like', this._id, (err, res) => {
            if (err) {
                // alert(err.reason) // simples
                swal({ type: 'info', title: 'Oopss..', text: err.reason })
            } else {
                return true;
            }
        });
    },
    'click .trash': function (event) {
        event.preventDefault();

        Meteor.call('posts.remove', this._id, (err, res) => {
            if (err) {
                swal({ type: 'error', title: err.reason });
                return false;
            }
        })

    }
})