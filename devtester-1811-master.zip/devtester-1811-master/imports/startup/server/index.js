// Import server startup through a single index entry point

import './fixtures.js';
import './register-api.js';
