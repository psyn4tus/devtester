// Register your apis here

import '../../api/links/methods.js';
import '../../api/posts/methods.js';
import '../../api/users/methods.js';
import '../../api/links/server/publications.js';
import '../../api/posts/server/publications.js';
